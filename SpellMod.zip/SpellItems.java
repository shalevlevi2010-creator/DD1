package spellmod;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.registry.Registry;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.HitResult;
import net.minecraft.entity.projectile.EntityHitResult;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class SpellItems {

    public static final Item SPELL_BOOK = new Item(new Item.Settings().maxCount(1)) {

        @Override
        public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
            if (w.isClient) return TypedActionResult.pass(p.getStackInHand(h));
            if (!(p instanceof net.minecraft.server.network.ServerPlayerEntity sp) || !SpellUtil.canCast(sp))
                return TypedActionResult.fail(p.getStackInHand(h));

            ItemStack off = p.getOffHandStack();

            // 🔥 כדור אש
            if (off.isOf(Items.GUNPOWDER)) {
                off.decrement(1);
                HitResult hit = p.raycast(20, 0, false);
                if (hit instanceof EntityHitResult ehr)
                    ehr.getEntity().damage(w.getDamageSources().magic(), 4);
                SpellUtil.particles(w, ParticleTypes.FLAME, p, 40);
                SpellUtil.sound(w, p, SoundEvents.ENTITY_BLAZE_SHOOT, 1.2f);
            }

            // 🕊️ תעופה
            if (off.isOf(Items.OAK_LEAVES) && off.getCount() >= 64) {
                off.decrement(64);
                p.getAbilities().allowFlying = true;
                p.getAbilities().flying = true;
                p.sendAbilitiesUpdate();
                SpellUtil.particles(w, ParticleTypes.CLOUD, p, 30);
                new Thread(() -> {
                    try { Thread.sleep(60000); } catch (Exception ignored) {}
                    p.getAbilities().allowFlying = false;
                    p.getAbilities().flying = false;
                    p.sendAbilitiesUpdate();
                }).start();
            }

            // ⚡ שיתוק
            if (off.isOf(Items.REDSTONE)) {
                off.decrement(1);
                if (p.raycast(10,0,false) instanceof EntityHitResult ehr) {
                    LivingEntity t = (LivingEntity)ehr.getEntity();
                    t.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS,60,255));
                    t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,60,255));
                    SpellUtil.particles(w, ParticleTypes.ELECTRIC_SPARK, t, 50);
                }
            }

            // 🛡️ הגנה
            if (off.isOf(Items.DIAMOND)) {
                off.decrement(1);
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE,340,10));
                SpellUtil.particles(w, ParticleTypes.ENCHANT, p, 80);
            }

            return TypedActionResult.success(p.getStackInHand(h));
        }
    };

    public static void register() {
        Registry.register(Registries.ITEM,
            new Identifier("spellmod","spell_book"), SPELL_BOOK);
    }
}