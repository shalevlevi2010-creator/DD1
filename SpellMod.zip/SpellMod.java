package spellmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

public class SpellMod implements ModInitializer {
    @Override
    public void onInitialize() {
        SpellItems.register();
        CommandRegistrationCallback.EVENT.register(
            (dispatcher, registryAccess, environment) -> SpellCommand.register(dispatcher));
    }
}