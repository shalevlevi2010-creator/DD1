package spellmod;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.World;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundCategory;
import net.minecraft.world.GameMode;

public class SpellUtil {

    public static boolean canCast(ServerPlayerEntity p) {
        return p.interactionManager.getGameMode() == GameMode.SURVIVAL
            || p.interactionManager.getGameMode() == GameMode.ADVENTURE;
    }

    public static void particles(World w, ParticleEffect p, Entity e, int c) {
        w.spawnParticles(p, e.getX(), e.getY()+1, e.getZ(), c, 0.5, 0.7, 0.5, 0);
    }

    public static void sound(World w, Entity e, SoundEvent s, float pitch) {
        w.playSound(null, e.getBlockPos(), s, SoundCategory.PLAYERS, 1f, pitch);
    }
}