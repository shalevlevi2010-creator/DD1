package spellmod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;

import static net.minecraft.server.command.CommandManager.literal;
import static net.minecraft.server.command.CommandManager.argument;

public class SpellCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {

        dispatcher.register(literal("spell")
            .then(literal("love")
                .then(argument("target", EntityArgumentType.entity())
                    .executes(ctx -> {
                        ServerPlayerEntity c = ctx.getSource().getPlayer();
                        if (!SpellUtil.canCast(c)) return 0;
                        LivingEntity t = (LivingEntity) EntityArgumentType.getEntity(ctx,"target");

                        c.getHungerManager().add(-4,0);
                        t.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS,200,255));
                        SpellUtil.particles(c.getWorld(), ParticleTypes.HEART, t, 20);
                        return 1;
                    })))

            .then(literal("judgement")
                .then(argument("target", EntityArgumentType.entity())
                    .executes(ctx -> {
                        ServerPlayerEntity c = ctx.getSource().getPlayer();
                        if (!SpellUtil.canCast(c)) return 0;
                        LivingEntity t = (LivingEntity) EntityArgumentType.getEntity(ctx,"target");

                        c.damage(c.getWorld().getDamageSources().magic(),12);
                        t.setHealth(2);
                        t.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS,300));
                        SpellUtil.particles(c.getWorld(), ParticleTypes.SOUL, c, 60);
                        SpellUtil.particles(c.getWorld(), ParticleTypes.SQUID_INK, t, 80);
                        return 1;
                    })))
        );
    }
}